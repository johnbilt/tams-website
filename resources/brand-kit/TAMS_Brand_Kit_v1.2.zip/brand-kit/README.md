# TAMS Brand Kit — v1.2

Primary lockup and bare mark, as vector SVG (wordmark converted to outlines — no fonts required) and transparent PNG (480px tall).

## Variants
- **color-dark** — duotone for dark backgrounds (white + Playhead Amber)
- **color-light** — duotone for light backgrounds (Control Navy + Playhead Amber)
- **mono-white / mono-navy** — single-colour versions

## Colours
- Control Navy `#141A28`
- Playhead Amber `#E5A144` (oklch 78% 0.15 70)
- Signal White `#FFFFFF`

## Rules
- Internal gap between mark and wordmark: **2 grid units** (mark height ÷ 6) — the same gutter used inside the mark. Baked into the SVG/PNG geometry; don't add space when placing them.
- Clearspace: one track height (5/12 of mark height) on all sides, outside the whole lockup
- Below 24px tall, use the mark in a tile, not the bare mark
- Don't re-stagger, rotate, outline, or recolour beyond the duotone
