# TAMS social assets

| File | Use |
|---|---|
| `linkedin-company-banner-1128x191.png` | LinkedIn **company page** cover. Left 300px is kept clear for the page logo overlay. Lockup, headline and descriptor line only. |
| `linkedin-hero-banner-1584x396.png` | LinkedIn **personal profile** cover. Content is right-aligned, clear of the avatar overlay. Lockup, one-line headline and descriptor only. |
| `linkedin-profile-400x400.png` | Profile / page logo. Upload the 400px version — LinkedIn downscales. |
| `linkedin-profile-300x300.png` | Same, at LinkedIn's stated minimum. |

Profile images use the bare mark on Control Navy at 28% of the tile height — it stays legible when LinkedIn crops to a circle. Do not use the lockup in a profile square; the wordmark becomes unreadable.

## Rendering

Assets are rendered at **3× supersample** with the real Geist Bold and IBM Plex Mono outlines (wordmark drawn from vector paths, not live text), then saved at 3× resolution. LinkedIn downscales on upload, which keeps edges crisp. Source layout: `TAMS Social Assets.html`.
