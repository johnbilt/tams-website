# TAMS brand — changelog

## v1.2 — August 2026
- **Lockup spacing corrected.** One canonical internal gap between mark and wordmark: **2 grid units (mark height ÷ 6)** — the same gutter used inside the mark. Previously the delivered SVG/PNG lockups carried a 6-unit gap and the HTML documents had drifted to several different ratios.
- Clarified that clearspace (one track height, 5/12 of mark height) applies **outside** the whole lockup and is a separate measure from the internal gap. Conflating the two caused the drift.
- Regenerated all lockup assets: SVG and PNG, horizontal and stacked, all four colour variants — plus `assets/logo/`, the GitHub Pages theme and the LinkedIn covers.
- Ecosystem badges withdrawn from the launch document, pending a future compatibility programme.

## v1.1 — August 2026
- Descriptor "time-addressable media store" removed from the primary lockup; the lockup is mark + wordmark only.
- Wordmark cap height locked to the mark height exactly, via cap-to-baseline trimming.
- Typeface change: JetBrains Mono → **IBM Plex Mono** for improved legibility.
- Language: TAMS is an open **specification**, never a standard. "time-addressable" is always hyphenated.

## v1.0 — July 2026
- Initial identity: Stagger mark, Master Control palette, Geist + mono pairing.
